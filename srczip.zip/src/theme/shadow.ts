export const SHADOW = {
  sm: "0 1px 2px rgba(0,0,0,.05)",
  md: "0 4px 6px rgba(0,0,0,.08)",
  lg: "0 10px 20px rgba(0,0,0,.12)",
};
